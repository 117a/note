[TOC]
##JS_ZS_6 call apply bind
###1.函数的三种身份
>- 普通函数
>- new 类,this实例
>- 函数类Function的一个实例
###2.函数私有属性
####1.name
函数名,匿名函数的名字是空字符串""
![Alt text](./1525830107202.png)
```javascript
    function fn() {
    }
    console.dir(fn);
    console.log(fn.name);//fn
    console.log(1,(function () {}).name);//1,""
```
name的特殊情况:
+1.通过构造函数方式创建的函数 new Function()的函数名是anonymous
+2.通过bind方法得到的一个函数的函数名是" bound+原来的函数名"
```
	function fn() {}
	
    var f=new Function ("x","x++;console.log(x)");
    var f1=new Function ("x","x++;console.log(x)");
    console.log(f.name);//anonymous
    console.log(f1.name);//anonymous
    
    var f2=fn.bind();
    console.log(f2.name);//bound fn
```
####2.caller 调用者
+当前函数在哪个函数中执行的,函数的caller就是谁
+函数若在全局中执行,函数的caller就是null
```
    function f() {
      console.log(f.caller);
      //f.caller();//死循环了
    }
    function f1() {
      f();
    }
    f1();//f1
    f();//null
```
###3.函数私有属性arguments的callee
>- arguments.callee:当前函数本身
   函数Fn.prototype.constructor也是函数本身Fn 
>- 递归:函数中自己调用自己
+当没有函数名时就可以使用arguments.callee进行递归
+注意箭头函数中没有arguments
```
function f() {
				      console.log(arguments.callee==f.prototype.constructor);
			      //true
}
f();
		function sum(n){
        if(n==0) return n;
        //return n+sum(n-1);
        return n+arguments.callee(n-1);
        //return n+sum.prototype.constructor(n-1);//19-21三行代码等价

    }
    console.log(sum(10));//55
    
    /*递归过程分析
    * n=10 return 10+sum(9)
    * n=9 return 10+9+sum(8)
    * n=8 return 10+9+8+sum(7)
    * n=0 return 10+9+8+7+....+0
    * */

    var a=(function (n) {
        if(n==0) return n;
        return n+arguments.callee(n-1);
    })(10);
    console.log(a);//5
```
###4.函数原型公有方法call
call是函数类Function原型上的一个公有的方法(函数),那么所有的函数都有call方法.
>+ call作用
	- 可以让前面的函数执行
	- 改变前面函数的this
>+ 参数
	- 第一个参数:是改变前面函数中的this的
		 call(obj); this->obj
	- 第二个参数起...:是给前面函数传参的
	`特例`
	+  call()/ call(null) /call(undefined)的this都是window
	+  如果这个参数是基本数据类型,默认将this变成了一个对象

`箭头函数中没有this,使用call方法改变不了this`
```
	function f1(x) {
        console.log(this);
        console.log(x);
	    }
    var obj={f1};
    f1.call();//Window
    f1.call(null);//Window
    f1.call(undefined);//Window
    obj.f1.call();//Window
    obj.f1.call(null);//Window
    obj.f1.call(undefined);//Window
    obj.f1();//Object
    f1.call(null,1);//Window 1
    
//如果这个参数是基本数据类型,默认将this变成了一个对象
	function f2() {
        console.log(this);
    }
    f2.call(1);//Number {1}
    console.log(Object(1));//Number {1}
    console.log(new Number(1));//Number {1}
    f2.call(true);//Boolean {true}
    
```
call例子
```
	function change(n) {
      this.innerHTML=parseFloat(this.innerHTML)+n;
    }

    box.onclick=function () {
      //this->box
      //change(2) this->window
      change.call(this,1);
    };
    box.onclick=function () {
      //自定义属性
      this.change=change;
      this.change(2);
    };
    box.onclick=function () {
      //this-box
      let f=(n)=>{this.innerHTML=parseFloat(this.innerHTML)+n;};
      f(4);//f是一个箭头函数没有this this指的是上一级中的this
    }
```
####.call.call
call也是函数也有call方法
f.call.call(x1)
call(x1)执行的时候让前面的函数f.call执行,将f.call中的this变成x1,而f.call()中this是f,将其变成x1,一旦变成x1,在call的内部就是让x1执行,此时x1必须是一个函数

两个及两个以上的call执行最终都是一个第一个参数通过call执行将剩下参数传给call 所以读第一个参数必须是函数
```
	function f(n) {
      console.log(n);
    }
    function f1(n,m){
      console.log(this);
      console.log(n+m);
    }
    var obj={};

    f.call.call(f1);
    //f1.call()  this->w  NaN
    f.call.call.call(f1,1,2);
    //f1.call(1,2)  this->new Number(1) NaN
    f.call.call.call.call(f1,1);
    //f1.call(1)  this->new Number(1) NaN
    f.call.call(f1,1,2,3);
    //f1.call(1,2,3)   this->new Number(1) 5
    f.call.call.call(f1,obj,1);
    //f1.call(obj,1)  this->obj  NaN
    f.call.call.call(f1,obj,1,3);
    //f1.call(obj,1,3)  this->obj 4
```
###5. 数组遍历方法forEach第二个参数问题

数组遍历方法forEach中第二个参数是用来改变第一个参数函数的this的
```
	Array.prototype.forEach=function (fn,obj) {
      for (var i=0;i<this.length;i++){
        fn.call(obj,this[i],i,ary);
      }
    };

    let ary=[1,2,3];
    ary.forEach(function (item,index,input) {
      console.log(this);
    })//Window Window Window
```
###6.apply 跟call效果一样
唯一不同的是传参的方式不同
第一个参数:修改this用的
第二个参数:数组/类数组,函数执行的时候把数组中的每一项传给函数
```
	function f(x,y) {
      console.log(x + y);
    }
    f(1,2);
    f.call(null,1,2);
    f.apply(null,[1,2]);


    //求数组的最大值
    let ary=[1,23,4,17,8,19,40];

    //1.先排序(从大到小) 获取数组ary[0]
    ary.sort((a,b)=>b-a);
    console.log(ary[0]);

    //2.Math.max
    //Math.max(1,23,4,17,8,19,40);
    //Math.max([1,23,4,17,8,19,40])
    Math.max(...ary);

    let m1=eval("Math.max("+ary+")");
    //"Math.max(1,23,4,17,8,19,40)"
    console.log(m1);

    //利用apply传参数的特点 传的是一个数组 但是给前面函数max()的时候就是将数组展开
    console.log(Math.max.apply(null, ary));

    //假设法
    var max=0;
    for (var i=0;i<ary.length;i++){
      if(ary[i]>max)max=ary[i];
    }
    console.log(max);
```
###7.bind
得到一个新函数跟原来的函数长的一样,但是this变了
只改变this,但不让函数执行
注意bind是有返回值,返回值就是得到的新函数
`总结 call bind apply区别`
`call 修改前面函数的this并执行函数
bind 修改this 不执行
apply  利用传参的特性`
```
function f1() {
      console.log(this);
    }
    let f2=f1.bind(1);
    console.log(f2==f1);
    f2();


    // Function.prototype.bind=function (obj) {
    //   //this执行bind的原函数 我们需要返回一个跟this长得一样的函数
    //   var fn=(new Function("return "+this))();
    //   //字符串拼接默认调用toString()
    //   //var fn=(new Function("return "+this.toString()))();
    //   return fn;
    // }
    // var f=f1.bind({});
    // f();

    function change(){
      this.innerHTML++;
    }
    box.change=change;
    //setInterval(change.bind(box),1000)
    box.onclick=function () {
      change.call(this)
    };
```
###8.toString
任何数据类型对应的类的原型上都有一个toString
但是Object原型上的toString比较特殊"[object Object]"


`利用Object原型上的toString的结果特点将里面的this变成想要检测的数据,得到对应的数据类型`
```
	// delete Array.prototype.toString;
    // delete Number.prototype.toString;
    // delete Boolean.prototype.toString;
    // delete String.prototype.toString;
    console.log(Array.prototype);
    let ary=[1,2];
    console.log(ary.toString());//"[object Array]"
    console.log(1..toString());//"[object Number]"
    console.log(true.toString());//"[object Boolean]"
    console.log("11".toString());//"[object String]"

	 Object.prototype.toString=function () {
       //typeClass this的类型
      var typeClass=this.constructor.name;
      return "[object "+typeClass+"]";
     };

    console.log(Object.prototype.toString.call([1, 2]));
    //[object Array]
    console.log(Object.prototype.toString.call(1));
    //[object Number]
    console.log(Object.prototype.toString.call(true));
    //[object Boolean]
    console.log(Object.prototype.toString.call(/\d/));
    //[object RegExp]
```
上面我们将Number Array Boolean String 原型上的toString属性删除之后都找的是Object原型上的toString ,通过观察发现结果是"[object 对应的类]"谁调用toString对应的类就是谁所属的类 即"[object this的类]"
###9.检测数据类型的方法
>- `typeof` 
+详细检测基本数据类型typeof null->object
+引用数据类型得到"object"和"function"
>- `instanceof` 检测数组和正则,检测实例是否属于某一个类(常用,检测数据类型不常用)
+基本数据类型通过字面量创建方式检测不到,使用构造函数方式可以检测
+引用数据类型没有问题
>- `constructor`:检测当前实例是否有这个类名,通过constructor得到所属类本身可以获取name属性,直接拿到类名(函数名)
+利用Object原型下面的`toString`方法将其this通过call方法变成想要检测的数据  (**常用且全面)
+缺点 null和undefined没有类名
>- `Object.prototype.toString.call()`
+通过object原型上的toString方法改变this来检测该数据类型,返回是一个字符串[object xxx] 
```
console.log(Object.prototype.toString.call(null));//[object Null]
  console.log(Object.prototype.toString.call(undefined));//[object Undefined]
  //console.log(Null);
  //console.log(Undefined);
```
###10.JSON
`定义`
 - JSON是一种数据格式,不是数据类型
 - JSON对象: 严格的对象,属性名使用双引号[不能使用单引号]包起来的对象,称为JSON对象
 -  JSON对象和普通对象操作上是一样的,唯一不同的是格式上的不同
自己创建的.json文件中写的内容是JSON字符串,字符必须使用双引号
`JSON对象上的方法`
只有两个:
>- JSON.parse() 将JSON字符串变成JSON对象
>- JSON.stringify()将JSON对象变成JSON字符串

```  
	 var obj1={"name":"珠峰","age":10};
    var arr1=[{"name":"珠峰1","age":10},{"name":"珠峰2","age":20}];
    console.log(1,JSON.stringify(arr1));
    //1 "[{"name":"珠峰1","age":10},{"name":"珠峰2","age":20}]"
 ```
 - JSON字符串  将JSON对使用单引号包起来
 var str='[{"name":"珠峰1","age":10},{"name":"珠峰2","age":20}]';
    console.log(JSON.parse(str));
    //[{name: "珠峰1", age: 10},{name: "珠峰2", age: 20}]
```
```
let obj={name:"珠峰",age:10};
    //'{name:"珠峰",age:10}';
let arr=[1,2,3];
function getJSONStr(value) {
      var str="";
      if(Object.prototype.toString.call(value)=="[object Object]"){
        str="{";
        for (var key in value){
          str+=key+":"+value[key]+","
        }
        str=str.slice(0,str.length-1);
        str+="}"
      }else if(Object.prototype.toString.call(value)=="[object Array]"){
        str="["+value.toString()+"]"
      }
      return str;
    }
    console.log(getJSONStr(obj));
    console.log(getJSONStr(arr));
    -----------
	function getMax() {
      //return Math.max(...arguments);
      //return Math.max.apply(null,arguments);
      console.log(JSON.stringify(arguments));
    }
    getMax(1,2,3,4);
```