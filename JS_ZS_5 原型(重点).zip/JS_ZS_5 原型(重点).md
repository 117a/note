[TOC]
##JS_ZS_5 原型(重点)
###1.字面量创建方式和构造函数创建方式的区别
`字面量创建方式`
let n=10;
`构造函数创建方式` new创建的都是对象
let n1=new Number(1);//=>此时n1是Number类的一个实例,n1也是一个对象
`区别`
>-1.对于基本数据类型
字面量创建方式和构造函数创建方式不一样
字面量创建方式得到一个值,使用instanceof判断是false
构造函数创建方式得到一个实例对象,使用instanceof判断是true

>-2.对于引用数据类型
字面量创建方式和构造函数创建方式是一样的
`对于基本数据类型,使用构造函数方式创建和字面量创建方式不一样,引用数据类型两种创建方式没什么区别`
```
    let n1=new Number(1);//此时n1是Number类的一个实例,n1也是一个对象
    console.log(typeof n1);//'object'
    console.log(n1);//Number
    let arr1=[1,2];
    let arr2=new Array(2,3);
    console.log(arr1, arr2);
```
`构造函数方式创建函数`
- new function("函数体")
- new function("形参","函数体")  不常用
```javascript
    let f1=new function("x","x++;return x;")
//    相当于
//    function f1(x) {
//        x++;
//        return x;
//    }
    console.log(f1(10));
```
###2.公有属性和私有属性
`原型上存储的是公有的属性和方法`
数组中的方法都是公有方法,只要是Array的实例都可以使用这些方法
- `hasOwnProperty`:判断是不是自己的私有属性
```
arr.hasOwnProperty("length");//=>true
```
- `'in'方法`:既可检测私有也可检测公有的方法和属性
```
"toString" in obj1;//=>true
```
- `for in`的特点
>1.先遍历属性名是数字的,按照从小到大的顺序
>2.既可以遍历私有属性也可以遍历公有属性,但是一些内置属性遍历不到
>3.像这些不可以使用for in遍历到的属性是不可枚举属性
```
for (var key in arr){
	console.log(key);
}
```

- `getOwnPropertyDescriptor`
查看对一个私有属性的描述信息:
- `getOwnPropertyDescriptors`
查看对象下面所有的私有属性 的描述信息
```
var arr=[];
var obj1={};
console.log(Object.getOwnPropertyDescriptor(arr,"length"));//=>{value: 0, writable: true, enumerable: false, configurable: false}
console.log(Object.getOwnPropertyDescriptors(obj1));
```
 configurable:是否可配置,可不可以删除这个属性
 writable:是否可修改
  enumerable:是否可枚举
- `getOwnPropertyNames`
获取所有的私有属性的名字 返回一个数组
```
var obj1={name:'test',age:'9'};
console.log(Object.getOwnPropertyNames(obj1));// ["name", "age"]
```
- `getPrototypeOf`
获取当前对象的所有类的原型
```
var obj1={name:'test',age:'9'};
console.log(Object.getPrototypeOf(obj1));
```
![Alt text](./1525766667576.png)

- `Object.is()`
判断两个值是不是相等,内部是使用===来比较的
```
console.log(Object.is(NaN, NaN));//true
console.log(Object.is(0,-0));//false
```
###3.数组原型的扩展
自己在数组的原型上扩展一个去重的方法
###4.数据原型方法的重写
 

    
